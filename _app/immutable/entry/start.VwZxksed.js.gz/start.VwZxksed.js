import{a as t}from"../chunks/BFCauvn0.js";export{t as start};
