import{a as t}from"../chunks/CNr3S0V9.js";export{t as start};
