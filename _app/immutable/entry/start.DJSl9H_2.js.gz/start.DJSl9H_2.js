import{a as t}from"../chunks/BBaOolVL.js";export{t as start};
