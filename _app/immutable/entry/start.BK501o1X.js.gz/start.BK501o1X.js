import{a as t}from"../chunks/CK7gBGgh.js";export{t as start};
