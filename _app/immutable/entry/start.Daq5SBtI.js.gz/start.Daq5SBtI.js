import{a as t}from"../chunks/CjV0PZwl.js";export{t as start};
