import{a as t}from"../chunks/70IZKpRH.js";export{t as start};
