import{a as t}from"../chunks/B6fJl1qO.js";export{t as start};
