import{a as t}from"../chunks/CO9bVxtc.js";export{t as start};
