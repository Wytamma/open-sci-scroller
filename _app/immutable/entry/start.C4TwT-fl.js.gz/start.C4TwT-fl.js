import{a as t}from"../chunks/B-rt6CA_.js";export{t as start};
