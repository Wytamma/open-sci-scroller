import{a as t}from"../chunks/BGDroevf.js";export{t as start};
