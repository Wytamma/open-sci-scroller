import{a as t}from"../chunks/C4poDpPg.js";export{t as start};
