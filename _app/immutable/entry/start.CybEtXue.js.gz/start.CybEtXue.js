import{a as t}from"../chunks/Bfu8iwZn.js";export{t as start};
