import{a as t}from"../chunks/DrO7UB-f.js";export{t as start};
