import{a as t}from"../chunks/Bu3UoQMc.js";export{t as start};
