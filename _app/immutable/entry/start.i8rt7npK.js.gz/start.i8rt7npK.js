import{a as t}from"../chunks/D52DV0aE.js";export{t as start};
