import{a as t}from"../chunks/CoEH-28S.js";export{t as start};
