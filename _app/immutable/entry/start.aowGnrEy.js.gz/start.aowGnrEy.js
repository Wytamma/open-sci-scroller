import{a as t}from"../chunks/Dc0Cbvy_.js";export{t as start};
