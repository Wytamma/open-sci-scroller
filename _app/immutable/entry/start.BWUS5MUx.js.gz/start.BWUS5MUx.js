import{a as t}from"../chunks/CogvcJVU.js";export{t as start};
