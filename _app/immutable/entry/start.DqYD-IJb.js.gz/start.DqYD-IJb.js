import{a as t}from"../chunks/GeZmQPsE.js";export{t as start};
