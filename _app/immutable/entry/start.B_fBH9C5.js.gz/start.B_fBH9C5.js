import{a as t}from"../chunks/Bsbho0HR.js";export{t as start};
