import{a as t}from"../chunks/BLq4pHOK.js";export{t as start};
